# 자바 ORM 표준 JPA 프로그래밍 - 책 예제

## 전체 프로젝트 다운로드 경로: [download](https://github.com/holyeye/jpabook/archive/master.zip)

### [인텔리제이에 예제 프로젝트 설정하기(최성훈님 제공)](https://medium.com/@oopchoi/jpa-%ED%94%84%EB%A1%9C%EA%B7%B8%EB%9E%98%EB%B0%8D-fc443b647ec8)

## 예제 코드 문제 해결

### 데이터베이스 접속 문제

- h2 데이터베이스를 실행한 다음에 웹브라우저에 `http://localhost:8082`를 입력해도 접속이 되지 않으면, localhost 대신에 127.0.0.1 IP를 직접 입력하세요. `http://127.0.0.1:8082`

