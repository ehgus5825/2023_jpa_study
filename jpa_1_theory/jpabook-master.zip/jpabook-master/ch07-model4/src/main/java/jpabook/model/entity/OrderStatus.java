package jpabook.model.entity;

/**
 * Created by holyeye on 2014. 3. 11..
 */
public enum OrderStatus {

    ORDER, CANCEL

}
