package jpabook.model.entity;

/**
 * Created by holyeye on 2014. 3. 11..
 */
public enum DeliveryStatus {
    READY, //준비
    COMP   //배송
}
