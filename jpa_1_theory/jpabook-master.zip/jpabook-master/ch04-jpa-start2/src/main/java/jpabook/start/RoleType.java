package jpabook.start;

/**
* Created by 1001218 on 15. 3. 27..
*/
public enum RoleType {
    ADMIN, USER
}
