package jpabook.jpashop.domain;

/**
 * Created by holyeye on 2014. 3. 11..
 */
public enum DeliveryStatus {
    READY, COMP
}
